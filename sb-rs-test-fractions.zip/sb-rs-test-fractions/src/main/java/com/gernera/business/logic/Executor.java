package com.gernera.business.logic;

import com.gernera.utils.Constants;

public class Executor {

	public String execute(String numerator1, String denominator1, String numerator2, String denominator2, String operation) {
		Fraction fraction1 = new Fraction(Integer.parseInt(numerator1), Integer.parseInt(denominator1));
		Fraction fraction2 = new Fraction(Integer.parseInt(numerator2), Integer.parseInt(denominator2));
		FractionOperations fractionOperation = new FractionOperations();
		String result = null;
		switch (operation) {
		case Constants.operationEqual:
			StringBuilder sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append(fraction1.equals(fraction2) ? " == " : " != ");
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			result = sb.toString();
			break;
		case Constants.operationCompare:
			sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append(fractionOperation.maxFraction(fraction1, fraction2));
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			result = sb.toString();
			break;
		case Constants.operationAddition:
			sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append("+");
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			sb.append("=");
			sb.append(fractionOperation.add(fraction1, fraction2));
			result = sb.toString();
			break;
		case Constants.operationSubtraction:
			result = " " + fractionOperation.subtract(fraction1, fraction2);
			sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append("-");
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			sb.append("=");
			sb.append(fractionOperation.subtract(fraction1, fraction2));
			result = sb.toString();
			break;
		case Constants.operationMultiplication:
			result = " " + fractionOperation.subtract(fraction1, fraction2);
			sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append("*");
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			sb.append("=");
			sb.append(fractionOperation.multiply(fraction1, fraction2));
			result = sb.toString();
			break;
		case Constants.operationDivision:
			result = " " + fractionOperation.subtract(fraction1, fraction2);
			sb = new StringBuilder();
			sb.append(fraction1.getNumerator());
			sb.append("/");
			sb.append(fraction1.getDenominator());
			sb.append("*");
			sb.append(fraction2.getNumerator());
			sb.append("/");
			sb.append(fraction2.getDenominator());
			sb.append("=");
			sb.append(fractionOperation.divide(fraction1, fraction2));
			result = sb.toString();
			break;
		}
		return result;
	}
}
