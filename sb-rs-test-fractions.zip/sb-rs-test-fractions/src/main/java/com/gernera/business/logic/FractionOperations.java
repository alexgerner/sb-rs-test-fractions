package com.gernera.business.logic;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class FractionOperations {

	// function to calculate Greatest Common Divisor - gcd - of two numbers
	int gcd(int a, int b) {
		if (a == 0)
			return b;

		return gcd(b % a, a);
	}
	// Function to convert the obtained fraction into it's simplest form  
    private  String lowest(int nomirator3, int denominator3)  
	{  
	   
	    int common_factor = gcd(nomirator3,denominator3);  
	  
	    // Converting both terms into simpler  
	    // terms by dividing them by common factor  
	    denominator3 = denominator3/common_factor;  
	    nomirator3 = nomirator3/common_factor; 
	    return new Fraction(nomirator3,denominator3).toString();
	}
	
	/*** function to calculate sum of two fractions ***/
	public String add(Fraction fraction1, Fraction fraction2) {
		int nomirator1 = fraction1.getNumerator();
		int nomirator2 = fraction2.getNumerator();
		int denominator1 = fraction1.getDenominator();
		int denominator2 = fraction2.getDenominator();
		int denominator3 = gcd(denominator1,denominator2);  
		denominator3 = (denominator1*denominator2)/denominator3;
		int nomirator3 = (nomirator1)*(denominator3/denominator1) + (nomirator2)*(denominator3/denominator2);  
		return lowest(nomirator3, denominator3);	
	}

	/*** function to calculate subtraction of two fractions ***/
	public String subtract(Fraction fraction1, Fraction fraction2) {
		int nomirator1 = fraction1.getNumerator();
		int nomirator2 = fraction2.getNumerator();
		int denominator1 = fraction1.getDenominator();
		int denominator2 = fraction2.getDenominator();
		int denominator3 = gcd(denominator1,denominator2);  
		denominator3 = (denominator1*denominator2)/denominator3;
		int nomirator3 = (nomirator1)*(denominator3/denominator1) - (nomirator2)*(denominator3/denominator2);  
		return lowest(nomirator3, denominator3);
	}
	/*** function to calculate multiplication of two fractions ***/
	public String multiply(Fraction fraction1, Fraction fraction2) {
		int nomirator1 = fraction1.getNumerator();
		int nomirator2 = fraction2.getNumerator();
		int denominator1 = fraction1.getDenominator();
		int denominator2 = fraction2.getDenominator(); 
		if (denominator1==0||denominator2==0) return "~";
		if (nomirator1==0||nomirator2==0) return "0";
		return (nomirator1*nomirator2)+"/"+(denominator1*denominator2);
	}
	/*** function to calculate division of two fractions ***/
	public String divide(Fraction fraction1, Fraction fraction2) {
		int nomirator1 = fraction1.getNumerator();
		int nomirator2 = fraction2.getNumerator();
		int denominator1 = fraction1.getDenominator();
		int denominator2 = fraction2.getDenominator();
		if (denominator1==0||denominator2==0) return "~";
		if (nomirator1==0||nomirator2==0) return "0";
		return (nomirator1*denominator2)+"/"+(nomirator2*denominator1);
	}
	
	public String maxFraction(Fraction fraction1, Fraction fraction2) 
	{ 
		if  (fraction1.equals(fraction2))  return "="; 
		int nomirator1 = fraction1.getNumerator();
		int nomirator2 = fraction2.getNumerator();
		int denominator1 = fraction1.getDenominator();
		int denominator2 = fraction2.getDenominator();
		if (denominator1==0||denominator2==0) return "~";
		double result = (nomirator1 * denominator2) - (nomirator2 * denominator1); 
		return(result > 0) ? ">" : "<";
	} 
}
