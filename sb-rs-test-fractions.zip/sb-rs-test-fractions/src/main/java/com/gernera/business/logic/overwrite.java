package com.gernera.business.logic;

public @interface overwrite {

}
