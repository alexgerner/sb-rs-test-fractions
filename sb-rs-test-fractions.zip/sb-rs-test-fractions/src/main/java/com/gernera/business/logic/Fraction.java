package com.gernera.business.logic;

public final class Fraction {
	private int numerator;
    private int denominator;
	
	public Fraction(int numerator, int denominator)	{
	   this.numerator=numerator;
	   this.denominator=denominator;
	}
	public int getDenominator() {
		return denominator;
	}
	public int getNumerator() {
		return numerator;
	}
	
          
	@Override
    public boolean equals(Object o) {
    	if ((o instanceof Fraction) && ((Fraction)o).getNumerator()==this.getNumerator() && ((Fraction)o).getDenominator()==this.getDenominator()) {
    		return true;
    	} else {
    		return false;
    	}
    }
	public String toString() { 
        return (this.numerator + "/" + this.denominator);
     } 
	
}


