package com.gernera.utils;

import java.util.LinkedHashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class Validator {
	private static final Logger logger = LoggerFactory.getLogger(Validator.class);
	
	public boolean validateFractions(final String numerator1, final String denominator1, final String numerator2, final String denominator2) {
		if (numerator1.equals(Constants.parameterNotProvided) ||
    	    denominator1.equals(Constants.parameterNotProvided) ||
    	    numerator2.equals(Constants.parameterNotProvided) ||
            denominator2.equals(Constants.parameterNotProvided)) {
			return false;
		}
        try {
     
        	int denom1 = Integer.parseInt(denominator1);
        	int denom2 = Integer.parseInt(denominator2);
            if ( denom1==0||denom2==0)  {
            	return false;
            }
        }  catch(NumberFormatException ex) {
            return false;
        }
        return true;
	}
	
	public boolean validateOperation(final String operation) {
		logger.debug("operation="+operation);   
        switch (operation) {
	        case Constants.operationEqual: return true;
	        case Constants.operationCompare: return true;
	        case Constants.operationAddition: return true; 
	        case Constants.operationSubtraction: return true;
	        case Constants.operationMultiplication: return true;
	        case Constants.operationDivision: return true;
            default: return false;
        }
	}

}
