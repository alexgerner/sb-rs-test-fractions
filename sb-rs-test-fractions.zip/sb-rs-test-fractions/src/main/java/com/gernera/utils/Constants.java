package com.gernera.utils;

public class Constants {
	private Constants() { } // Prevents instantiation 
	public static final String messageWrongInputParameters = "Input Parameters Non Provided Or Wrong!";
	public static final String messageApplicationStarted = "--Application Started--";
	public static final String messageApplicationFinished = "--Application Finished--";
	public static final String messageRequest = "Request:";
	public static final String messageResponse = "=";
	public static final String parameterNotProvided="Parameter Not Provided"; 
	public static final String operationEqual = "equal";
	public static final String operationCompare = "compare";
	public static final String operationAddition = "add";
	public static final String operationSubtraction = "subtract";
	public static final String operationMultiplication = "multiply";
	public static final String operationDivision = "divide";
	
}
