package com.gernera.app;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.gernera.business.logic.Executor;
import com.gernera.utils.Constants;

import com.gernera.utils.Validator;

@RestController
public class ApplicationController {
	
	private static final Logger logger = LoggerFactory.getLogger(ApplicationController.class);

    @Autowired
	private ApplicationProperties applicationProperties; 
    @RequestMapping("/greeting")
    public Greeting greeting(@RequestParam(value="numerator1", defaultValue=Constants.parameterNotProvided) String numerator1,
                             @RequestParam(value="numerator2", defaultValue=Constants.parameterNotProvided) String numerator2,
                             @RequestParam(value = "denominator1", defaultValue = Constants.parameterNotProvided) String denominator1,
    	                     @RequestParam(value = "denominator2", defaultValue = Constants.parameterNotProvided) String denominator2,
    	                     @RequestParam(value = "operation", defaultValue = Constants.parameterNotProvided) String operation) {
    	logger.info(Constants.messageApplicationStarted); 

    	if (numerator1.equals(Constants.parameterNotProvided) || denominator1.equals(Constants.parameterNotProvided)
				|| numerator2.equals(Constants.parameterNotProvided)
				|| denominator2.equals(Constants.parameterNotProvided)) {
			return new Greeting(Constants.messageWrongInputParameters);
		}
		Validator validator = new Validator();

		if (validator.validateOperation(operation) == false
				|| validator.validateFractions(numerator1, denominator1, numerator2, denominator2) == false) {
			return new Greeting(Constants.messageWrongInputParameters);
		}
		
		String response=new Executor().execute(numerator1, denominator1, numerator2, denominator2,operation);
		logger.info(response);
    	return new Greeting(response);
    }
}
