package com.gernera.app.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.gernera.business.logic.Fraction;
import com.gernera.business.logic.FractionOperations;
import com.gernera.utils.Constants;


public class TestsFractionMultiplicationOperation {
	LinkedHashSet<Pattern> regexpSetPrecomile = null;
	 @Before
	    public void init() {
		 	
		
	    }

	@Test 
	public void validateFractionMultiplicationOperationSuccess() throws Exception {
	    	String methodName = new Object() {
			}.getClass().getEnclosingMethod().getName();
	    	System.out.println(methodName);
	    	Fraction fraction1 = new Fraction(3,4);
	    	Fraction fraction2 = new Fraction(1,2);
	    	String result = new FractionOperations().multiply(fraction1, fraction2);
	    	System.out.println(result);
	        Assert.assertEquals(result,"3/8");
	    }
	@Test
	public void validateFractionMultiplicationOperationNegativeNomirator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(-1, 1);
		Fraction fraction2 = new Fraction(3, 4);
		String result = new FractionOperations().multiply(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "-3/4");
	}
	@Test
	public void validateFractionMultiplicationOperationZeroNomirator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(0, 1);
		Fraction fraction2 = new Fraction(3, 4);
		String result = new FractionOperations().multiply(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "0");
	}
	
	@Test
	public void validateFractionAdditionOperationNegativeDeNominator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(-1, 1);
		Fraction fraction2 = new Fraction(3,0);
		String result = new FractionOperations().multiply(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "~");
	}
}
