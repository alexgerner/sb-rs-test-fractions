package com.gernera.app.tests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.gernera.utils.Constants;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TestsInputParameters {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void validateNoInputParameters() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " no parameters");
		this.mockMvc.perform(get("/greeting")).andDo(print()).andExpect(status().isOk()).andExpect(jsonPath("$.content")
				.value("Input Parameters Non Provided Or Wrong!"));
	}
	
	@Test
	public void validateInputParamPasswordIsGood() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName + " parameters good");
		this.mockMvc.perform(get("/greeting?numerator1=1&denominator1=4&numerator2=1&denominator2=2&operation=compare")).andDo(print()).andExpect(status().isOk())
				.andExpect(jsonPath("$.content")
			    .value("1/4<1/2"));
	}
}
