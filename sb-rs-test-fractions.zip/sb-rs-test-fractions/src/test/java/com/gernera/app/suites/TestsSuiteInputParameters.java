package com.gernera.app.suites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.gernera.app.tests.TestsInputParameters;

@RunWith(Suite.class)
@SuiteClasses({ TestsInputParameters.class })
public class TestsSuiteInputParameters {

}
