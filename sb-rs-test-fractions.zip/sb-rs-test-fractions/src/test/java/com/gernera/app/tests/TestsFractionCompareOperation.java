package com.gernera.app.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.gernera.business.logic.Fraction;
import com.gernera.business.logic.FractionOperations;
import com.gernera.utils.Constants;


public class TestsFractionCompareOperation {
	LinkedHashSet<Pattern> regexpSetPrecomile = null;
	 @Before
	    public void init() {
		 	
		
	    }

	@Test
	public void validateFractionCompareOperationMore() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(5, 8);
		Fraction fraction2 = new Fraction(1, 2);
		String result = new FractionOperations().maxFraction(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result,">");
	}
	
	@Test
	public void validateFractionCompareOperationLess() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(1, 2);
		Fraction fraction2 = new Fraction(5, 8);
		String result = new FractionOperations().maxFraction(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result,"<");
	}
	@Test
	public void validateFractionCompareOperationEqual() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(1, 2);
		Fraction fraction2 = new Fraction(1, 2);
		String result = new FractionOperations().maxFraction(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result,"=");
	}
	@Test
	public void validateFractionCompareOperationZroDenominator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(1, 0);
		Fraction fraction2 = new Fraction(1, 2);
		String result = new FractionOperations().maxFraction(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result,"~");
	}
}
