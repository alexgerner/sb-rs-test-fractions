package com.gernera.app.suites;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.gernera.app.tests.TestsFractionAdditionOperation;
import com.gernera.app.tests.TestsFractionCompareOperation;
import com.gernera.app.tests.TestsFractionDivisionOperation;
import com.gernera.app.tests.TestsFractionMultiplicationOperation;
import com.gernera.app.tests.TestsFractionSubstractionOperation;

@RunWith(Suite.class)
@SuiteClasses({TestsFractionAdditionOperation.class, TestsFractionSubstractionOperation.class, TestsFractionMultiplicationOperation.class, TestsFractionDivisionOperation.class,TestsFractionCompareOperation.class})
public class TestSuiteOperations {

}
