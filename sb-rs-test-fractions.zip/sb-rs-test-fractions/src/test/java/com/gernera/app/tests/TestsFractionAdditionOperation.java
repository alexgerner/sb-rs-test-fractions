package com.gernera.app.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.gernera.business.logic.Fraction;
import com.gernera.business.logic.FractionOperations;
import com.gernera.utils.Constants;


public class TestsFractionAdditionOperation {
	LinkedHashSet<Pattern> regexpSetPrecomile = null;
	 @Before
	    public void init() {
		 	
		
	    }

	@Test
	public void validateFractionAdditionOperationSuccess() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(1, 2);
		Fraction fraction2 = new Fraction(3, 4);
		String result = new FractionOperations().add(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "5/4");
	}
	@Test
	public void validateFractionAdditionOperationNegativeNomirator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(-1, 1);
		Fraction fraction2 = new Fraction(3, 4);
		String result = new FractionOperations().add(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "1/-4");
	}
	@Test
	public void validateFractionAdditionOperationZeroNomirator() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(0, 1);
		Fraction fraction2 = new Fraction(3, 4);
		String result = new FractionOperations().add(fraction1, fraction2);
		System.out.println(result);
		Assert.assertEquals(result, "3/4");
	}

}
