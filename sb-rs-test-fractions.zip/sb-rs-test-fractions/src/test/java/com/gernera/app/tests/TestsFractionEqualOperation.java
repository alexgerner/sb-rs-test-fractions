package com.gernera.app.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.gernera.business.logic.Fraction;
import com.gernera.business.logic.FractionOperations;
import com.gernera.utils.Constants;


public class TestsFractionEqualOperation {
	LinkedHashSet<Pattern> regexpSetPrecomile = null;
	 @Before
	    public void init() {
		 	
		
	    }

	@Test
	public void validateFractionEqualsOperationSuccess() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(1, 2);
		Fraction fraction2 = new Fraction(1, 2);
		boolean result = fraction1.equals(fraction2);
		System.out.println(result);
		Assert.assertEquals(result,true);
	}
	
	@Test
	public void validateFractionEqualsOperationFailure() throws Exception {
		String methodName = new Object() {
		}.getClass().getEnclosingMethod().getName();
		System.out.println(methodName);
		Fraction fraction1 = new Fraction(3, 2);
		Fraction fraction2 = new Fraction(1, 2);
		boolean result = fraction1.equals(fraction2);
		System.out.println(result);
		Assert.assertEquals(result,false);
	}
}
